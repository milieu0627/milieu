package com.demo.entity;

import com.baomidou.mybatisplus.enums.IdType;
import java.math.BigDecimal;
import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.activerecord.Model;
import com.baomidou.mybatisplus.annotations.TableName;
import java.io.Serializable;

/**
 * <p>
 * 
 * </p>
 *
 * @author wangwei
 * @since 2018-03-30
 */
@TableName("gw_advance_payment")
public class AdvancePayment extends Model<AdvancePayment> {

    private static final long serialVersionUID = 1L;

    /**
     * 主键
     */
	@TableId(value="id", type= IdType.AUTO)
	private Integer id;
    /**
     * 预付款单号【如：YHK2016090001】
     */
	private String code;
    /**
     * 购物中心信息表【gw_mall_info】ID
     */
	@TableField("mall_info_id")
	private Integer mallInfoId;
    /**
     * 商户表【gw_merchants_info】的bm
     */
	@TableField("merchants_info_bm")
	private String merchantsInfoBm;
    /**
     * 合同主表【gw_contract_a】的contractcode
     */
	@TableField("contract_code")
	private String contractCode;
    /**
     * 是否允许核销（0-不允许核销，1-允许核销）
     */
	private Integer type;
    /**
     * 预付款日期【如：2010-09-11】
     */
	@TableField("payment_date")
	private String paymentDate;
    /**
     * 预付款总金额
     */
	@TableField("payment_total_money")
	private BigDecimal paymentTotalMoney;
    /**
     * 核销类型（0-无，1-结算组别，2-费用项目）
     */
	@TableField("cancel_type")
	private Integer cancelType;
    /**
     * 核销的费用项目编号(有多个用,分隔)
     */
	@TableField("cancel_cost_code")
	private String cancelCostCode;
    /**
     * 核销的费用项目编码对应的核销金额(有多个用,分隔)
     */
	@TableField("cancel_cost_money")
	private String cancelCostMoney;
    /**
     * 剩余可用金额
     */
	@TableField("over_plus_money")
	private BigDecimal overPlusMoney;
    /**
     * 核销总金额
     */
	@TableField("cancel_total_money")
	private BigDecimal cancelTotalMoney;
    /**
     * 预付款描述
     */
	private String description;
    /**
     * 备注
     */
	private String note;
    /**
     * 状态（1-新增，2-确认，3-反确认，4-确认核销，5-反确认核销）
     */
	private Integer status;
    /**
     * 创建时间
     */
	@TableField("create_time")
	private String createTime;
    /**
     * 创建人ID（用户表【gw_admin_users】的id）
     */
	@TableField("create_user_id")
	private Integer createUserId;
    /**
     * 修改时间
     */
	@TableField("update_time")
	private String updateTime;
    /**
     * 修改人ID（用户表【gw_admin_users】的id）
     */
	@TableField("update_user_id")
	private Integer updateUserId;
    /**
     * 确认人
     */
	@TableField("confirm_user_id")
	private Integer confirmUserId;
    /**
     * 确认时间
     */
	@TableField("confirm_time")
	private String confirmTime;
    /**
     * 反确认人
     */
	@TableField("unconfirm_user_id")
	private Integer unconfirmUserId;
    /**
     * 反确认时间
     */
	@TableField("unconfirm_time")
	private String unconfirmTime;


	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public Integer getMallInfoId() {
		return mallInfoId;
	}

	public void setMallInfoId(Integer mallInfoId) {
		this.mallInfoId = mallInfoId;
	}

	public String getMerchantsInfoBm() {
		return merchantsInfoBm;
	}

	public void setMerchantsInfoBm(String merchantsInfoBm) {
		this.merchantsInfoBm = merchantsInfoBm;
	}

	public String getContractCode() {
		return contractCode;
	}

	public void setContractCode(String contractCode) {
		this.contractCode = contractCode;
	}

	public Integer getType() {
		return type;
	}

	public void setType(Integer type) {
		this.type = type;
	}

	public String getPaymentDate() {
		return paymentDate;
	}

	public void setPaymentDate(String paymentDate) {
		this.paymentDate = paymentDate;
	}

	public BigDecimal getPaymentTotalMoney() {
		return paymentTotalMoney;
	}

	public void setPaymentTotalMoney(BigDecimal paymentTotalMoney) {
		this.paymentTotalMoney = paymentTotalMoney;
	}

	public Integer getCancelType() {
		return cancelType;
	}

	public void setCancelType(Integer cancelType) {
		this.cancelType = cancelType;
	}

	public String getCancelCostCode() {
		return cancelCostCode;
	}

	public void setCancelCostCode(String cancelCostCode) {
		this.cancelCostCode = cancelCostCode;
	}

	public String getCancelCostMoney() {
		return cancelCostMoney;
	}

	public void setCancelCostMoney(String cancelCostMoney) {
		this.cancelCostMoney = cancelCostMoney;
	}

	public BigDecimal getOverPlusMoney() {
		return overPlusMoney;
	}

	public void setOverPlusMoney(BigDecimal overPlusMoney) {
		this.overPlusMoney = overPlusMoney;
	}

	public BigDecimal getCancelTotalMoney() {
		return cancelTotalMoney;
	}

	public void setCancelTotalMoney(BigDecimal cancelTotalMoney) {
		this.cancelTotalMoney = cancelTotalMoney;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getNote() {
		return note;
	}

	public void setNote(String note) {
		this.note = note;
	}

	public Integer getStatus() {
		return status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}

	public String getCreateTime() {
		return createTime;
	}

	public void setCreateTime(String createTime) {
		this.createTime = createTime;
	}

	public Integer getCreateUserId() {
		return createUserId;
	}

	public void setCreateUserId(Integer createUserId) {
		this.createUserId = createUserId;
	}

	public String getUpdateTime() {
		return updateTime;
	}

	public void setUpdateTime(String updateTime) {
		this.updateTime = updateTime;
	}

	public Integer getUpdateUserId() {
		return updateUserId;
	}

	public void setUpdateUserId(Integer updateUserId) {
		this.updateUserId = updateUserId;
	}

	public Integer getConfirmUserId() {
		return confirmUserId;
	}

	public void setConfirmUserId(Integer confirmUserId) {
		this.confirmUserId = confirmUserId;
	}

	public String getConfirmTime() {
		return confirmTime;
	}

	public void setConfirmTime(String confirmTime) {
		this.confirmTime = confirmTime;
	}

	public Integer getUnconfirmUserId() {
		return unconfirmUserId;
	}

	public void setUnconfirmUserId(Integer unconfirmUserId) {
		this.unconfirmUserId = unconfirmUserId;
	}

	public String getUnconfirmTime() {
		return unconfirmTime;
	}

	public void setUnconfirmTime(String unconfirmTime) {
		this.unconfirmTime = unconfirmTime;
	}

	@Override
	protected Serializable pkVal() {
		return this.id;
	}

}
