package com.demo.entity;

import com.baomidou.mybatisplus.enums.IdType;
import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.activerecord.Model;
import com.baomidou.mybatisplus.annotations.TableName;
import java.io.Serializable;

/**
 * <p>
 * 管理员用户表
 * </p>
 *
 * @author wangwei
 * @since 2018-03-30
 */
@TableName("gw_admin_users")
public class AdminUsers extends Model<AdminUsers> {

    private static final long serialVersionUID = 1L;

    /**
     * 主键ID
     */
	@TableId(value="id", type= IdType.AUTO)
	private Integer id;
    /**
     * 管理员登录账号
     */
	private String username;
    /**
     * 管理员登录密码
     */
	private String password;
    /**
     * 管理员姓名
     */
	private String name;
    /**
     * 管理员最后登录时间
     */
	private String dtime;
    /**
     * 用户权限组ID
     */
	@TableField("gw_role_id")
	private Integer gwRoleId;
    /**
     * 管理员联系电话
     */
	private String phone;
    /**
     * 身份证号码
     */
	private String sfz;
    /**
     * 身份证住址
     */
	private String address;
    /**
     * 状态( -1 删除 0-冻结  1-正常（在职），2-离职)
     */
	private Integer state;
    /**
     * 性别（0-男，1-女）
     */
	private String sex;
    /**
     * 部门编号
     */
	@TableField("gw_department_code")
	private String gwDepartmentCode;
    /**
     * 职位编号
     */
	private String positions;
    /**
     * 邮箱号
     */
	private String email;
    /**
     * QQ号
     */
	private String qq;
    /**
     * 创建人id
     */
	@TableField("create_user_id")
	private Integer createUserId;
    /**
     * 创建时间
     */
	@TableField("create_time")
	private String createTime;
    /**
     * 更新人
     */
	@TableField("update_user_id")
	private Integer updateUserId;
    /**
     * 管理员状态（0-sso认证系统新增用户，1-用户已在本系统完善用户资料及授权）
     */
	private Integer type;
	@TableField("role_list")
	private String roleList;
    /**
     * 更新时间
     */
	@TableField("update_time")
	private String updateTime;
	private String salt;


	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDtime() {
		return dtime;
	}

	public void setDtime(String dtime) {
		this.dtime = dtime;
	}

	public Integer getGwRoleId() {
		return gwRoleId;
	}

	public void setGwRoleId(Integer gwRoleId) {
		this.gwRoleId = gwRoleId;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getSfz() {
		return sfz;
	}

	public void setSfz(String sfz) {
		this.sfz = sfz;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public Integer getState() {
		return state;
	}

	public void setState(Integer state) {
		this.state = state;
	}

	public String getSex() {
		return sex;
	}

	public void setSex(String sex) {
		this.sex = sex;
	}

	public String getGwDepartmentCode() {
		return gwDepartmentCode;
	}

	public void setGwDepartmentCode(String gwDepartmentCode) {
		this.gwDepartmentCode = gwDepartmentCode;
	}

	public String getPositions() {
		return positions;
	}

	public void setPositions(String positions) {
		this.positions = positions;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getQq() {
		return qq;
	}

	public void setQq(String qq) {
		this.qq = qq;
	}

	public Integer getCreateUserId() {
		return createUserId;
	}

	public void setCreateUserId(Integer createUserId) {
		this.createUserId = createUserId;
	}

	public String getCreateTime() {
		return createTime;
	}

	public void setCreateTime(String createTime) {
		this.createTime = createTime;
	}

	public Integer getUpdateUserId() {
		return updateUserId;
	}

	public void setUpdateUserId(Integer updateUserId) {
		this.updateUserId = updateUserId;
	}

	public Integer getType() {
		return type;
	}

	public void setType(Integer type) {
		this.type = type;
	}

	public String getRoleList() {
		return roleList;
	}

	public void setRoleList(String roleList) {
		this.roleList = roleList;
	}

	public String getUpdateTime() {
		return updateTime;
	}

	public void setUpdateTime(String updateTime) {
		this.updateTime = updateTime;
	}

	public String getSalt() {
		return salt;
	}

	public void setSalt(String salt) {
		this.salt = salt;
	}

	@Override
	protected Serializable pkVal() {
		return this.id;
	}

}
