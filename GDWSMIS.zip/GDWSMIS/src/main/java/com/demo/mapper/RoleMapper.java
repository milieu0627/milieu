package com.demo.mapper;

import com.demo.entity.Role;

import org.springframework.stereotype.Repository;

import com.baomidou.mybatisplus.mapper.BaseMapper;

/**
 * <p>
  * 用户权限组 Mapper 接口
 * </p>
 *
 * @author wangwei
 * @since 2018-04-02
 */
@Repository
public interface RoleMapper extends BaseMapper<Role> {

}