package com.demo.mapper;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.demo.entity.AdminUsers;

/**
 * <p>
  * 管理员用户表 Mapper 接口
 * </p>
 *
 * @author wangwei
 * @since 2018-03-30
 */
@Repository
public interface AdminUsersMapper extends BaseMapper<AdminUsers> {
	/**
	 * 查询所有用户
	 * @return
	 */
	List<AdminUsers> getAdminUsrList(Map<String, Object> params);
}