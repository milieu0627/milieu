package com.demo.mapper;

import com.demo.entity.AdvancePayment;

import org.springframework.stereotype.Service;

import com.baomidou.mybatisplus.mapper.BaseMapper;

/**
 * <p>
  *  Mapper 接口
 * </p>
 *
 * @author wangwei
 * @since 2018-03-30
 */
@Service
public interface AdvancePaymentMapper extends BaseMapper<AdvancePayment> {

}