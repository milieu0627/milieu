package com.demo.enums;

import com.demo.enums.NameValueEnum;

public enum BaseResultCodeEnum implements NameValueEnum{
	/**
	 * 1000,"代码错误"
	 */
	CODE_ERROR(1000,"代码错误"),
	/**
	 * 2000,"发生异常"
	 */
	EXCEPTION_ERROR(2000,"发生异常"),
	/**
	 * 0000,"操作成功"
	 */
	SUCCESS(0000,"操作成功"),
	/**
	 * 3000,"空数据"
	 */
	NULL_DATA(3000,"空数据"),
	/**
	 * -1000,"数据库插入错误"
	 */
	INSR_FAILD(-1000,"数据库插入错误"),
	/**
	 * -2000,"数据库删除错误"
	 */
	DELE_FAILD(-2000,"数据库删除错误"),
	/**
	 * -3000 参数错误
	 */
	PARA_ERROR(-3000,"参数错误")
	;

	/**
     * 数据库对应的值
     */
    private Integer value;
	/**
	 * 页面显示的值
	 */
	private String displayName;

	public static String getDisplayName(Integer value){
		for (BaseResultCodeEnum enums : BaseResultCodeEnum.values()) {
			if(enums.value == value){
				return enums.displayName;
			}
		}
		return "";
	}

	private BaseResultCodeEnum(Integer value, String displayName) {
		this.value = value;
		this.displayName = displayName;
	}

	public String getDisplayName() {
		return displayName;
	}

	public Integer getValue() {
		return value;
	}

}
