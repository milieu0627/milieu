package com.demo.util;
/**
 * 公共路径请求前缀类
 * @author mills
 *
 */
public class BasepathUtil {
	/**
	 * 请求页面前缀
	 */
	private static final  String URI_FIX="/adminUsers/";
	/**
	 * 用户模块请求前缀
	 */
	public static final  String URI_ADMIN="/admin/";
	/**
	 * 错误资源请求前缀
	 */
	private static final   String URI_ERR="/error/";
}
