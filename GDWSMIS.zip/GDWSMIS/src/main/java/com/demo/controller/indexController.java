package com.demo.controller;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
/**
 * 请求主页
 * @author mills
 *
 */
@Controller
@RequestMapping("/index")
public class indexController {
	//引入日志
	private final static Logger logger = LoggerFactory.getLogger(indexController.class);
	/**
	 * 请求前缀地址
	 */
	private String  URI_FIX="admin/";
	/**
	 * 请求首页
	 * @return
	 */
	@RequestMapping(value="/toIndex" ,method=RequestMethod.GET)
	public String toIndex(HttpServletRequest request,HttpServletResponse response) {
		/**
		 * 补丁：修改直接请求首页，校验是否登录
		 */
		logger.info("请求首页");
		//获取session
		HttpSession session=request.getSession();
		//获取sesison保存用户信息
		String username=session.getAttribute("username").toString();
		//校验用户是否存在
		if ("".equals(username) || username.equals(null)) {
			//不存在，直接重定向到登录页面
			try {
				logger.info("未登录，直接请求首页，跳转登陆");
				response.sendRedirect("localhost:8700/login/toLogin");
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		return URI_FIX+"index1";
	}
	/**
	 * 请求用户测试列表
	 * @return
	 */
	@RequestMapping(value ="/test" , method=RequestMethod.GET)
	public String toUserList() {
		logger.info("请求用户测试列表");
		return URI_FIX+"test";
	}
	/**
	 * 请求主页
	 * @return
	 */
	@RequestMapping(value ="/main" , method=RequestMethod.GET)
	public String main() {
		logger.info("请求主页");
		return URI_FIX+"main";
	}
	/**
	 * 请求角色管理
	 * @return
	 */
	@RequestMapping(value = "/toNav" , method = RequestMethod.GET)
	public String nav() {
		logger.info("请求角色列表");
		return URI_FIX+"nav";
	}
}
