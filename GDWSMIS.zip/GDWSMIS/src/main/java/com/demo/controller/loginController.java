package com.demo.controller;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.baomidou.mybatisplus.mapper.EntityWrapper;
import com.demo.entity.AdminUsers;
import com.demo.enums.BaseResultCodeEnum;
import com.demo.service.AdminUsersService;
import com.demo.util.BaseResultUtil;

/**
 * 登陆控制层
 * @author mills
 *
 */
@Controller
@RequestMapping(value ="/login")
public class loginController{
	//日志
	private final static Logger logger = LoggerFactory.getLogger(loginController.class);
	
	/**
	 * 注入用户服务层
	 */
	@Autowired
	private AdminUsersService adminUsersService;
	
	/**
	 * 跳转登陆页面
	 * @return
	 */
	@RequestMapping(value ="/toLogin" , method =RequestMethod.GET)
	public String toLogin() {
		//日志
		logger.info("请求登陆页面");
		return "/login";
	}
	/**
	 * 验证登陆
	 * @param request 当前请求
	 * @param username 用户名
	 * @param password 密码
	 * @return 若校验成功则跳转到主页，若失败，则提示失败信息
	 */
	@RequestMapping(value ="/toLogin" ,method=RequestMethod.POST)
	@ResponseBody
	public BaseResultUtil login(HttpServletResponse response,HttpServletRequest request,@RequestParam String username,@RequestParam String password) {
		//返回值对象
		BaseResultUtil baseResultUtil =new BaseResultUtil();
		//校验参数
		if (username.equals(null) || "".equals(username)   || password.equals(null) || "".equals(password)) {
			//返回错误信息
			baseResultUtil.setCode(BaseResultCodeEnum.PARA_ERROR.getValue().toString());
			baseResultUtil.setMsg("用户名或密码不能为空");
			return baseResultUtil;
		}
		//参数校验 通过，进行正确性校验，根据用户名获取密码
		AdminUsers adminUsers=adminUsersService.selectOne(new EntityWrapper<AdminUsers>().eq("username", username));
		//判断是否存在该用户，若不存在则请求注册地址
		if (adminUsers==null) {
			//返回无用户不存在，请求注册地址
			baseResultUtil.setCode(BaseResultCodeEnum.NULL_DATA.getValue().toString());
			//返回下一操作地址-注册地址
			baseResultUtil.setNextOperate("/login/regist");
			//提示信息
			baseResultUtil.setMsg(username+"未注册");
			//设置数据
			baseResultUtil.setData(null);
/*			try {
				response.sendRedirect("http://localhost:8700/login/regist");
			} catch (IOException e) {
				e.printStackTrace();
			}*/ 
			return baseResultUtil;
		}
		//若用户存在-校验密码是否正确
		if (!password.equals(adminUsers.getPassword())) {
			//若密码不同，返回用户名或密码错误，增强安全性
			baseResultUtil.setCode(BaseResultCodeEnum.PARA_ERROR.getValue().toString());
			//提示信息
			baseResultUtil.setMsg("用户名或密码错误!");
			//返回信息
			return baseResultUtil;
		}
		//若密码校验成功，则将登陆信息方法session，并跳转到主页
		HttpSession session=request.getSession();
		//放入session  用户名
		session.setAttribute("username", username);
		//用户ID
		session.setAttribute("userId", adminUsers.getId());
		//设置返回值信息
		baseResultUtil.setCode(BaseResultCodeEnum.SUCCESS.getValue().toString());
		//返回下一步操作地址
		baseResultUtil.setNextOperate("/index/toIndex");
		//返回用户信息-页面取值
		baseResultUtil.setData(adminUsers);
		return baseResultUtil;
	}
	/**
	 * 请求注册页面
	 * @return
	 */
	@RequestMapping(value ="/regist" ,method =RequestMethod.GET)
	public String toRegist() {
		//日志
		logger.info("请求注册页面");
		return "register";
	}
	
	/**
	 * 注册
	 * @param request  当前请求
	 * @param response  当前返回
	 * @param adminUsers  封装成对象的参数
	 * @return
	 */
	@RequestMapping(value ="/regist" ,method =RequestMethod.POST	)
	@ResponseBody
	@Cacheable
	public BaseResultUtil regists(HttpServletRequest request,HttpServletResponse response,AdminUsers adminUsers) {
		//返回值对象
		BaseResultUtil baseResultUtil =new BaseResultUtil();
		//检查参数是否为空
		if ("".equals(adminUsers.getUsername()) || adminUsers.getUsername().equals(null) || 
				"".equals(adminUsers.getPassword()) || adminUsers.getPassword().equals(null)) {
			//若为空，返回参数错误
			baseResultUtil.setCode(BaseResultCodeEnum.PARA_ERROR.getValue().toString());
			//提示信息
			baseResultUtil.setMsg("用户名或密码不能为空");
			//返回信息
			baseResultUtil.setData(null);
			return baseResultUtil;
		}
		//检查电话号码是否为空
		if ("".equals(adminUsers.getPhone()) || adminUsers.getPhone().equals(null)) {
			//返回电话号码不能为空
			baseResultUtil.setCode(BaseResultCodeEnum.PARA_ERROR.getValue().toString());
			//提示信息
			baseResultUtil.setMsg("电话号码不能为空");
			return baseResultUtil;
		}
		//通过验证-进入保存方法
		try {
			Integer result=adminUsersService.savaAdminUsers(adminUsers);
			//校验是否保存成功
			if (result<1) {
				//未出异常单为保存到数据库
				baseResultUtil.setCode(BaseResultCodeEnum.INSR_FAILD.getValue().toString());
				//提示信息
				baseResultUtil.setMsg("保存失败!");
				//下一跳
				baseResultUtil.setNextOperate("/login/regist");
				return baseResultUtil;
			}
		} catch (Exception e) {
			e.printStackTrace();
			logger.info("注册用户发生异常:"+e.getMessage());
			//返回数据库操作异常代码
			baseResultUtil.setCode(BaseResultCodeEnum.EXCEPTION_ERROR.getValue().toString());
			//提示信息
			baseResultUtil.setMsg("发生系统错误");
			//下一跳
			baseResultUtil.setNextOperate("/login/regist");
			return baseResultUtil;
		}
		//操作成功
		baseResultUtil.setCode(BaseResultCodeEnum.SUCCESS.getValue().toString());
		//提示信息
		baseResultUtil.setMsg("保存成功");
		//下一跳
		baseResultUtil.setNextOperate("/login/toLogin");
		return baseResultUtil;
	}
}
