package com.demo.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.demo.entity.AdminUsers;
import com.demo.enums.BaseResultCodeEnum;
import com.demo.service.AdminUsersService;
import com.demo.util.BaseResultUtil;



/**
 * <p>
 * 管理员用户表 前端控制器
 * </p>
 *
 * @author wangwei
 * @since 2018-03-30
 */
@Controller
@RequestMapping("/adminUsers")
public class AdminUsersController {
	//日志
	private Logger logger = LoggerFactory.getLogger(AdminUsersController.class);
	/**
	 * 请求页面前缀
	 */
	private String URI_FIX="/adminUsers/";
	/**
	/**
	 * 注入用户服务层
	 */
	@Autowired
	private AdminUsersService adminUsersService;
	/**
	 * 获取用户主页
	 * @return 返回用户列表页面
	 */
	@RequestMapping(value ="/user" , method = RequestMethod.GET)
	public String toAdminUserList() {
		return URI_FIX+"userList";
	}
	/**
	 * 获取编辑页面
	 * @return
	 */
	@RequestMapping(value="/editUser",method=RequestMethod.GET)
	public String getEditPage() {
		return URI_FIX+"editUser";
	}
	/**
	 * 获取用户列表集合
	 * @return
	 */
	@RequestMapping(value="/userList" , method=RequestMethod.GET)
	@ResponseBody
	@Cacheable
	BaseResultUtil userList(@RequestParam Integer page,@RequestParam Integer limit){
		//参数
		Map<String, Object> params=new HashMap<>();
		//分页数据
		params.put("page", page);
		params.put("limit", limit);
		//返回数据对象
		BaseResultUtil baseResultUtil=new BaseResultUtil();
		//调用服务层获取全部数据
		List<AdminUsers> resultList=adminUsersService.getAdminUserList(params);
		//设置返回数据
		baseResultUtil.setData(resultList);
		//成功代码
		baseResultUtil.setCode(BaseResultCodeEnum.SUCCESS.getValue().toString());
		//提示信息
		baseResultUtil.setMsg("");
		//总记录数
		baseResultUtil.setCount(resultList.size());
		return baseResultUtil;
	}
	/**
	 * 保存用户
	 * @param adminUsers  用户对象
	 * @param request
	 * @return
	 */
	@RequestMapping(value ="/user" , method =RequestMethod.POST)
	@Cacheable
	@ResponseBody
	BaseResultUtil insertUser(AdminUsers adminUsers,HttpServletRequest request) {
		//返回信息对象
		BaseResultUtil baseResultUtil = new BaseResultUtil();
		//判断对象是否为空
		if(adminUsers ==null) {
			logger.info("保存用户信息错误");
			//提示信息
			baseResultUtil.setMsg("数据异常");
			//返回结果
			return baseResultUtil;
			
		}
		//保存数据
		boolean result=adminUsersService.insert(adminUsers);
		//判断是否保存成功
		if (!result) {
			//提示信息
			baseResultUtil.setMsg("保存失败");
			//返回状态码
			baseResultUtil.setCode(BaseResultCodeEnum.INSR_FAILD.getValue().toString());
			//返回结果
			return baseResultUtil;
		}
		//提示信息
		baseResultUtil.setMsg("保存成功");
		//操作状态码
		baseResultUtil.setCode(BaseResultCodeEnum.SUCCESS.getValue().toString());
		return baseResultUtil;
	}
	/**
	 * 根据ID删除一条数据
	 * @param id
	 * @return
	 */
	@RequestMapping(value="/user", method=RequestMethod.DELETE)
	@ResponseBody
	//从缓存中删除数据
	@CacheEvict(beforeInvocation=true)
	BaseResultUtil deleteUser(Integer id) {
		//返回公共对象
		BaseResultUtil baseResultUtil =new BaseResultUtil();
		try {
			//调用服务层删除数据方法
			boolean result=adminUsersService.deleteById(id);
			//判断是否删除成功
			if (!result) {
				//提示信息
				baseResultUtil.setMsg("未删除数据!");
				//操作码
				baseResultUtil.setCode(BaseResultCodeEnum.DELE_FAILD.getValue().toString());
				
				return baseResultUtil;
			}
		} catch (RuntimeException e) {
			e.printStackTrace();
			//提示信息
			baseResultUtil.setMsg("发生错误！");
			//操作码
			baseResultUtil.setCode(BaseResultCodeEnum.EXCEPTION_ERROR.getValue().toString());
			
			return baseResultUtil;
		}
		//返回数据
		//提示信息
		baseResultUtil.setMsg("删除成功!");
		//操作码
		baseResultUtil.setCode(BaseResultCodeEnum.SUCCESS.getValue().toString());
		return baseResultUtil;
	}
}
