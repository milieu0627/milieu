package com.demo.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.baomidou.mybatisplus.mapper.EntityWrapper;
import com.demo.entity.Role;
import com.demo.enums.BaseResultCodeEnum;
import com.demo.service.RoleService;
import com.demo.util.BaseResultUtil;

/**
 * <p>
 * 用户权限组 前端控制器
 * </p>
 *
 * @author wangwei
 * @since 2018-04-02
 */
@Controller
@RequestMapping("/role")
public class RoleController {
	//引入日志
	private final static Logger logger = LoggerFactory.getLogger(RoleController.class);
	
	/**
	 * 引入角色权限服务层
	 */
	@Autowired
	private RoleService roleService;
	
	/**
	 * 查询全部用户权限组信息
	 * @param page  分页信息
	 * @param PageNumber
	 * @param request
	 * @return 全部用户权限信息集合
	 */
	@RequestMapping(value ="/roleList", method= RequestMethod.GET)
	@ResponseBody
	public BaseResultUtil getAllRoleList(@RequestParam Integer page,@RequestParam Integer PageNumber,HttpServletRequest request) {
		//构造返回值
		BaseResultUtil baseResultUtil =new BaseResultUtil();
		//日志
		logger.info("查询全部用户列表");
		//查询全部用户权限数据
		List<Role> roleList=roleService.selectList(new EntityWrapper<Role>());
		//判断是否为空数据
		if (roleList ==null || roleList.size() <1) {
			//记入日志
			logger.info("查询用户权限全部数据为空或不存在");
			//返回信息
			baseResultUtil.setMsg("无用户权限数据");
			//返回状态
			baseResultUtil.setCode(BaseResultCodeEnum.NULL_DATA.getValue().toString());
			//返回null
			baseResultUtil.setData(null);
		}
		//提示信息
		baseResultUtil.setMsg("查询成功");
		//状态码
		baseResultUtil.setCode(BaseResultCodeEnum.SUCCESS.getValue().toString());
		//查询数据
		baseResultUtil.setData(roleList);
		//总记录数
		baseResultUtil.setCount(roleList.size());
		//返回数据
		return baseResultUtil;
	}
}
