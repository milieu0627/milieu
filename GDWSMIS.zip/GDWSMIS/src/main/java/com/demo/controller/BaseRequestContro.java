package com.demo.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

/**
 * 公共请求控制层-主要用于公共资源，如：错误页面的请求，或者其他公共资源请求
 * @author mills
 *
 */
@Controller
@RequestMapping("/base")
public class BaseRequestContro {
	//日志
	private final static Logger logger =LoggerFactory.getLogger(BaseRequestContro.class);
	//请求地址前缀
	private String URI_ERR="/error/";
	
	/**
	 * 请求错误页面
	 * @return
	 */
	@RequestMapping(value ="/error" ,method =RequestMethod.GET)
	public String toError() {
		//请求公共错误页面
		logger.info("请求公共错误页面");
		return URI_ERR+"error";
	}
}
