package com.demo.service;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;

import com.baomidou.mybatisplus.service.IService;
import com.demo.entity.AdminUsers;

/**
 * <p>
 * 管理员用户表 服务类
 * </p>
 *
 * @author wangwei
 * @since 2018-03-30
 */
@Service
public interface AdminUsersService extends IService<AdminUsers> {
	/**
	 * 获取所有用户
	 * @return
	 */
	List<AdminUsers> getAdminUserList(Map<String , Object> params);
	/**
	 * 保存用户
	 * @param adminUsers
	 * @return
	 */
	Integer savaAdminUsers(AdminUsers adminUsers);
}
