package com.demo.service;

import com.demo.entity.AdvancePayment;
import com.baomidou.mybatisplus.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author wangwei
 * @since 2018-03-30
 */
public interface AdvancePaymentService extends IService<AdvancePayment> {
	
}
