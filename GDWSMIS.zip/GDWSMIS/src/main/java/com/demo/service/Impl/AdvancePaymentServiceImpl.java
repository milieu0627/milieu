package com.demo.service.Impl;

import com.demo.entity.AdvancePayment;
import com.demo.mapper.AdvancePaymentMapper;
import com.demo.service.AdvancePaymentService;
import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author wangwei
 * @since 2018-03-30
 */
@Service
public class AdvancePaymentServiceImpl extends ServiceImpl<AdvancePaymentMapper, AdvancePayment> implements AdvancePaymentService {
	
}
