package com.demo.service.Impl;

import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.baomidou.mybatisplus.mapper.EntityWrapper;
import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import com.demo.entity.Role;
import com.demo.mapper.RoleMapper;
import com.demo.service.RoleService;

/**
 * <p>
 * 用户权限组 服务实现类
 * </p>
 *
 * @author wangwei
 * @since 2018-04-02
 */
@Service
public class RoleServiceImpl extends ServiceImpl<RoleMapper, Role> implements RoleService {
	//引入日志
	private final static Logger logger = LoggerFactory.getLogger(RoleServiceImpl.class);
	/**
	 * 注入用户权限组数据层
	 */
	@Autowired
	private RoleMapper roleMapper;
	/**
	 * 
	 * @param params查询条件参数
	 * @return
	 */
	public List<Role> getRoleList(Map<String, Object> params){
		//数据层查询所有方法
		List<Role> roleList=roleMapper.selectList(new EntityWrapper<Role>());
		//判断是否为空
		if(roleList ==null || roleList.size()<1) {
			logger.info("查询用户权限组信息为空");
			return null;
		}
		return roleList;
	}
}
