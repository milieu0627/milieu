package com.demo.service.Impl;

import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import com.demo.entity.AdminUsers;
import com.demo.mapper.AdminUsersMapper;
import com.demo.service.AdminUsersService;
import com.demo.util.DateUtil;

/**
 * <p>
 * 管理员用户表 服务实现类
 * </p>
 *
 * @author wangwei
 * @since 2018-03-30
 */
@Service
//引入事物;
@Transactional(propagation=Propagation.REQUIRED,rollbackFor=Exception.class)
public class AdminUsersServiceImpl extends ServiceImpl<AdminUsersMapper, AdminUsers> implements AdminUsersService {
	//开启日志
	private final static Logger logger =LoggerFactory.getLogger(AdminUsersServiceImpl.class);
	/**
	 * 注入用户数据层
	 */
	@Autowired
	private AdminUsersMapper adminUsersMapper;
	@Override
	public List<AdminUsers> getAdminUserList(Map<String, Object> params) {
		//调用数据层获取全部数据方法
		List<AdminUsers> adminUserList=adminUsersMapper.getAdminUsrList(params);
		logger.info("查询全部数据");
		return adminUserList;
	}
	@Override
	public Integer savaAdminUsers(AdminUsers adminUsers) {
		//服务层-具体逻辑
		//设置注册日期
		adminUsers.setCreateTime(DateUtil.getDatetime());
		//设置用户名--当前用户名同登陆账号一致
		adminUsers.setName(adminUsers.getUsername());
		//---目前只做以上一些操作
		//调用数据层保存用户方法
		Integer result=adminUsersMapper.insert(adminUsers);
		return result;
	}
}
