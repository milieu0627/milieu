package com.demo.service;

import com.demo.entity.Role;

import org.springframework.stereotype.Service;

import com.baomidou.mybatisplus.service.IService;

/**
 * <p>
 * 用户权限组 服务类
 * </p>
 *
 * @author wangwei
 * @since 2018-04-02
 */
@Service
public interface RoleService extends IService<Role> {
	
}
